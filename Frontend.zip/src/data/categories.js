// src/data/categories.js
export const categories = [
  "Science",
  "Technology",
  "Engineering",
  "Mathematics",
  "Arts",
  "History",
  "Business",
  "Literature",
  "Other", // only upload uses this
];
